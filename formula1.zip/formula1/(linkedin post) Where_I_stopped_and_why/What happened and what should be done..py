# Databricks notebook source
# MAGIC %md
# MAGIC ##### In race_results - The spark driver has stopped unexpectedly and is restarting. Your notebook will be automatically reattached.- has occured and don't have time to look into it. 
# MAGIC ##### If it is processed, run the rest of the notebooks and vizualizations. 